Welcome to the Last Stand!
Our game has a tutorial that you can play through. This can be accessed through the main menu.
There is also a seperate guide within the game that can access from the main menu, or
anytime while playing the game with the "Guide" button on the home page of the player shop, 
which can be accessed with the 'P' key.

Gameplay summary of the guide:
Defend yourself and your base from repeating waves of enemy robots. Each robot you defeat,
you earn one point that you can spend in the shop to buy weapons, ammo, health, and defenses.
Robots automatically choose to attack what is closer to them, so do not leave your base undefended.
Your first goal should be to save enough money to buy 1 or 2 defensives towers. These towers
are automatically placed around your base and defend it from incoming robots. You can purchase up
to 4. When you've purchased a couple of towers, you can then go out and explore the maze. You need
to find the locations of the 3 spawners and destroy them. To destroy a spawner, you must first approach
it. Once you get close enough, its shield will come down, leaving it vunerable to damage from your weapons.
However, disabling a spawner's shield will spawn a boss wave of robots, so be aware. Once you defeat all 3
spawners, you win. You lose if you die or your base is destroyed.